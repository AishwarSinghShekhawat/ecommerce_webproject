<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="exp1.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>trektents</title>
</head>
<style>
    h1{text-align: center;}
    body {
        background-image: url("im7.jpg"); background-repeat: no-repeat;background-size: cover;
    }
</style> 
<hr>
<h1>"WELCOME TO TREK TENT" </h1> 
<br>
 <a href="login.html" style="color:red">LETS LOGIN </a> &emsp;&emsp;<a href="register.html" style="color:red">JOIN US</a>
<hr>
<h3>ABOUT US :</h3> </font>
<font color="white"> <p> We provide quality of portable tents and equipments on rents for your destination all over India at affordable pricing keeping in mind that majority of students from college and schools wants to explore the unexplored.<br>Giving us services means you are not only carrying your bedroom but also kitchen with yourself yes you heard it right .<br>
    You can also rents portable stoves ,foldable chairs,utensils,etc.You sure need special shoes for a trek and a bit of special soul as well. Walk past some of the best creations of nature and treat your eyes with tall mountains, gushing water, colourful view and cool breeze. Trekking gives you innumerable opportunities to stay close to nature and explore the charm of the world's geographical diversities. It promises you an undisturbed experience in the lap of nature, where you can explore a great variety of flora and fauna. The best time to go trekking depends on the climatic conditions of the region and the route you plan to follow. Among the regions in India with the most varied topography are the mighty Himalayan mountains. You may start hiking on the vast northern plains below the Shivalik foothills and travel to the ranges' highest points. Trails through the foothills are generally smooth, and you will experience not much elevation. On ascending higher, the paths will start becoming tougher and more challenging. With the passage of time, many new paths and destinations are being discovered and utilised for hiking. Among the variety of trekking trails that India has to offer some are listed here, Ladakh, Nandi hills, Manali, Munnar, Matheran, Nainital, Kasol, Coorg, Chikmanglur, Kasauli, Leh, Cherrapunji, Shillong, Paro, Lansdowne, Dalhousie, Coonoor, Yercaud, Wayanad, Mahabaleshwar, etc.</p></font>
    <br>
    <center> <a href="index.php">OUR CATALOGUE FOR RENTING THINGS CLICK HERE</a> </center>
    <hr>
<center><h2><font color="brown">THINGS WE OFFER  </font> </h2></center> 

<div class="row">
    <div class="column">
      <img src="photo72.jpg" alt="Snow" style="width:100%">
    </div>
    <div class="column">
      <img src="photos74.jpg" alt="Forest" style="width:100%">
    </div>
    <div class="column">
      <img src="op.jpg" alt="Mountains" style="width:100%">
    </div>
  </div>
<ol>  <font color="white" ><li><b>Tent(2 persons,waterproof) (For Mumbai,Delhi,Pune,Hyderabad and Shillong)</b></li>
    <li><b>Tent(4 persons,waterproof)(For Mumbai,Delhi,Pune,Hyderabad and Shillong)</b></li>
    <li><b>Clean Sleeping Bag</b></li> </font> </ol>
    <center><img src="photo76.jpg" width="600"></center>
    <ol start="4">
     <font color="white">  <li><b>Tent mattress </b></li>
        <li><b>Trekking poles </b></li>
        <li><b>cylinder </b></li> 

    </font>

    </ol>
    <hr>
    

</html>   
